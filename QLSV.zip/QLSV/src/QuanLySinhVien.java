import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class QuanLySinhVien {
    private ArrayList<SinhVien> sinhViens;
    public static final String TEN_FILE = "students.csv";
    public static final String DAU = ", ";

    public QuanLySinhVien() {
        ArrayList<SinhVien> sinhVienList = new ArrayList<>();
        this.sinhViens = sinhVienList;
    }

    public SinhVien nhapDuLieuSV() {
        int maSV;
        String hoTen;
        int tuoi;
        String gioiTinh;
        String diaChi;
        double diemTB;
        Scanner scanner = new Scanner(System.in);

        System.out.println("Mã sinh viên: ");
        maSV = scanner.nextInt();
        scanner = new Scanner(System.in);
        System.out.println("Họ tên: ");
        hoTen = scanner.nextLine();

        System.out.println("Tuổi: ");
        tuoi = scanner.nextInt();
        scanner = new Scanner(System.in);
        System.out.println("Giới tính: ");
        gioiTinh = scanner.nextLine();
        scanner = new Scanner(System.in);
        System.out.println("Đia chỉ: ");
        diaChi = scanner.nextLine();
        System.out.println("Điểm trung bình: ");
        diemTB = scanner.nextDouble();

        SinhVien sinhVien = new SinhVien(maSV, hoTen, tuoi, gioiTinh, diaChi, diemTB);
        return sinhVien;
    }

    public void themSV(SinhVien sinhVien) {
        String line = null;
        line = sinhVien.getMaSV() + DAU + sinhVien.getHoTen() + DAU + sinhVien.getTuoi() + DAU + sinhVien.getGioiTinh() + DAU + sinhVien.getDiaChi() + DAU + sinhVien.getDiemTB();
        try {
            FileWriter fileWriter = new FileWriter(TEN_FILE, true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(line);
            bufferedWriter.newLine();
            bufferedWriter.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String toString() {
        return "QuanLySinhVien{" +
                "sinhViens=" + sinhViens +
                '}';
    }

    private void capNhatBangMaSV(int maSV) {
        List<SinhVien> sinhVienList = readSinhViensFromFile();
        for (int i = 0; i < sinhVienList.size(); i++) {
            if (sinhVienList.get(i).getMaSV() == maSV) {
                String hoTen;
                int tuoi;
                String gioiTinh;
                String diaChi;
                double diemTB;
                Scanner scanner = new Scanner(System.in);

                System.out.print("Họ tên: ");
                hoTen = scanner.nextLine();

                System.out.print("Tuổi: ");
                tuoi = scanner.nextInt();

                System.out.print("Giới tính: ");
                gioiTinh = scanner.nextLine();

                System.out.print("Đia chỉ: ");
                diaChi = scanner.nextLine();

                System.out.print("Điểm trung bình: ");
                diemTB = scanner.nextDouble();

                sinhVienList.get(i).setHoTen(hoTen);
                sinhVienList.get(i).setTuoi(tuoi);
                sinhVienList.get(i).setGioiTinh(gioiTinh);
                sinhVienList.get(i).setDiaChi(diaChi);
                sinhVienList.get(i).setDiemTB(diemTB);
            }
        }

        for (int i = 0; i < sinhVienList.size(); i++) {
            String line = null;
            line = sinhVienList.get(i).getMaSV() + DAU + sinhVienList.get(i).getHoTen() + DAU + sinhVienList.get(i).getTuoi() + DAU + sinhVienList.get(i).getGioiTinh() + DAU + sinhVienList.get(i).getDiaChi() + DAU + sinhVienList.get(i).getDiemTB();
            try {
                FileWriter fileWriter;
                if (i == 0) {
                    fileWriter = new FileWriter(TEN_FILE, false);
                } else {
                    fileWriter = new FileWriter(TEN_FILE, true);
                }
                fileWriter = new FileWriter(TEN_FILE, true);
                BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                bufferedWriter.write(line);
                bufferedWriter.newLine();
                bufferedWriter.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private void hienThiDanhSachSV(List<SinhVien> sinhVienList) {
        for (SinhVien sinhVien: sinhVienList) {
            System.out.println("Mã sinh viên: " + sinhVien.getMaSV()  + "Họ tên: " + sinhVien.getHoTen() + "Tuổi: " + sinhVien.getTuoi() + "Giới tính: " + sinhVien.getGioiTinh() + "Địa chỉ: " + sinhVien.getDiaChi() + "Điểm trung bình: " + sinhVien.getDiemTB());
        }
    }

    private int nhapMaSV() {
        System.out.println("Mã sinh viên: ");
        Scanner scanner = new Scanner(System.in);
        int maSV = scanner.nextInt();
        return maSV;
    }
    private List<SinhVien> readSinhViensFromFile() {
        List<String> listLine = new ArrayList<>();
        List<SinhVien> sinhVienList = new ArrayList<>();
        try {
            FileReader fileReader = new FileReader(TEN_FILE);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line = null;
            while ((line = bufferedReader.readLine()) != null) {
                listLine.add(line);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        for (String line: listLine) {
            String[] lineSplit = line.split(DAU);
            SinhVien sinhVien = new SinhVien(Integer.parseInt(lineSplit[0]), lineSplit[1], Integer.parseInt(lineSplit[2]), lineSplit[3], lineSplit[4],  Double.parseDouble(lineSplit[5]));
            sinhVienList.add(sinhVien);
        }
        return sinhVienList;
    }
    public void menu() {
        char choice = '?';
        while (choice != '5') {
            System.out.println("--cHƯƠNG TRÌNH QUẢN LÝ SINH VIÊN--");
            System.out.println("Chọn chức năng theo số:");
            System.out.println("1. Xem danh sách sinh viên");
            System.out.println("2. Thêm mới");
            System.out.println("3. Cập nhật");
            System.out.println("4. Xóa");
            System.out.println("5. Thoát");
            System.out.print("Chọn chức năng: ");
            Scanner scanner = new Scanner(System.in);
            choice = scanner.nextLine().charAt(0);
            switch (choice) {
                case '1': {
                    List<SinhVien> sinhVienList = readSinhViensFromFile();
                    hienThiDanhSachSV(sinhVienList);
                    break;}
                case '2': {
                    SinhVien sinhVien = nhapDuLieuSV();
                    themSV(sinhVien);
                    break;}
                case '3': {
                    int maSV = nhapMaSV();
                    capNhatBangMaSV(maSV);
                    break;}
                case '4': {
                    System.out.println("Xóa");
                    break;}
            }
        }
    }
}